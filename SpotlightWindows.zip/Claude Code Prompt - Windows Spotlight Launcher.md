# PROJECT: Spotlight for Windows

You are working on a personal Windows desktop utility called **Spotlight for Windows**.

The application is inspired by the interaction model of macOS Spotlight, but it must NOT be a pixel-perfect clone. The goal is to create a fast, lightweight, keyboard-first launcher and search utility for Windows.

The application must prioritize:

1. Extremely fast launch time.
2. Instant global keyboard access.
3. Minimal CPU and memory usage while idle.
4. Keyboard-first interaction.
5. Clean, minimal UI.
6. Good search relevance.
7. Maintainable architecture.
8. Incremental development rather than building everything at once.

Target environment:

- Windows 11
- .NET 10
- C#
- WPF
- x64
- Desktop application
- No administrator privileges required for normal operation

Do NOT use Electron.
Do NOT use Python as the main application runtime.
Do NOT build this as a web application.
Do NOT implement the entire roadmap in one phase.

---

# PRODUCT VISION

The application should behave approximately like this:

User presses:

Alt + Space

A centered search panel appears.

Example:

    ┌───────────────────────────────────────────────┐
    │ 🔍  Search anything...                       │
    ├───────────────────────────────────────────────┤
    │                                               │
    │ ▣ Visual Studio Code                          │
    │   Application                                 │
    │                                               │
    │ 📄 Terra ERP.xlsx                             │
    │   File                                        │
    │                                               │
    │ 📁 Projects                                   │
    │   Folder                                      │
    │                                               │
    │ 🧮 25 × 35 = 875                              │
    │   Calculator                                  │
    │                                               │
    └───────────────────────────────────────────────┘

The user should be able to:

- press Alt + Space
- immediately type
- see relevant results
- navigate with Up/Down
- press Enter to execute
- press Esc to dismiss

The application should normally stay running in the background.

---

# IMPORTANT DEVELOPMENT RULES

These rules apply to every phase.

## Rule 1 — Phase boundaries

Only implement the current phase.

Do NOT implement features belonging to later phases unless they are necessary for the current phase to work.

Do not create:

- AI search
- semantic search
- plugin architecture
- content indexing
- cloud synchronization
- advanced settings
- unnecessary abstractions

before their designated phase.

## Rule 2 — Inspect before modifying

Before writing code:

1. Inspect the current repository.
2. Inspect the existing project structure.
3. Inspect the `.csproj`.
4. Inspect dependencies.
5. Inspect existing build/test configuration.
6. Understand the current implementation.

Never blindly overwrite working code.

## Rule 3 — Prefer native Windows APIs

Use native Windows capabilities whenever practical.

Examples include:

- RegisterHotKey
- Windows Shell APIs
- Windows Search
- Windows Registry where appropriate
- Windows Explorer integration
- Win32 window APIs

Avoid third-party libraries when the Windows/.NET platform already provides the required capability.

## Rule 4 — Performance

This application is intended to run continuously.

Never perform:

- full filesystem scans on every keystroke
- synchronous expensive operations on the UI thread
- unnecessary polling loops
- continuous high-frequency timers
- unnecessary background workers

Search should be asynchronous.

UI must remain responsive.

## Rule 5 — Architecture

Keep these concerns separated:

- UI
- ViewModels
- Search
- Search providers
- Ranking
- Windows integration
- persistence
- configuration

Do not place all application logic inside `MainWindow.xaml.cs`.

## Rule 6 — No magic constants where avoidable

Configuration such as:

- hotkey
- maximum visible results
- debounce duration
- startup behavior
- theme preference

should eventually be configurable.

However, do not build a complete Settings UI until its designated phase.

## Rule 7 — Logging

Create a lightweight logging strategy.

Do not spam logs.

Logs should help diagnose:

- application startup
- hotkey registration failures
- search provider failures
- application launch failures
- unexpected exceptions

Do not log every keystroke.

## Rule 8 — Error handling

The application must fail gracefully.

A broken search provider must not crash the entire application.

For example:

If file search fails:

- application search should still work.

If an application fails to launch:

- show/log an appropriate error.

## Rule 9 — Accessibility and keyboard support

Keyboard input is a primary interaction mechanism.

Do not make mouse interaction a requirement.

## Rule 10 — Build after meaningful changes

After implementing a meaningful unit of work:

- build the solution
- fix compilation errors
- run relevant tests
- do not leave the project in a broken state

---

# PHASE 0 — PROJECT FOUNDATION

Goal:

Create a clean, minimal WPF application foundation.

Tasks:

1. Create or validate a .NET 10 WPF project.
2. Configure x64 target if appropriate.
3. Enable nullable reference types.
4. Enable implicit usings where appropriate.
5. Establish clean folder organization.

Recommended initial structure:

    SpotlightWindows/
    │
    ├── App.xaml
    ├── App.xaml.cs
    │
    ├── Core/
    │   ├── Models/
    │   ├── Interfaces/
    │   └── Services/
    │
    ├── Infrastructure/
    │   └── Windows/
    │
    ├── UI/
    │   ├── Views/
    │   ├── ViewModels/
    │   ├── Controls/
    │   └── Themes/
    │
    ├── Data/
    │
    ├── Resources/
    │
    └── Tests/

Do not over-engineer the structure.

Create only the abstractions that have an immediate purpose.

Create a basic application window.

The application should:

- compile
- launch
- close correctly
- have a basic application lifecycle

Do not implement search yet.

Do not implement the global hotkey yet.

Do not implement the tray icon yet.

At the end of this phase provide:

1. Files created.
2. Files modified.
3. Dependencies added and why.
4. Build result.
5. Test result.
6. Any architectural decisions.
7. Exact command I should use to start the application.

STOP after completing this phase.

---

# PHASE 1 — SPOTLIGHT WINDOW + GLOBAL HOTKEY

Goal:

Create the basic Spotlight interaction.

When the user presses:

Alt + Space

the launcher should appear.

When the user presses:

Esc

the launcher should disappear.

Requirements:

## Global hotkey

Use the Windows native global hotkey mechanism.

Do not create a keyboard polling loop.

The implementation should:

- register Alt + Space
- unregister when the application exits
- handle registration failure
- avoid duplicate registration

## Window behavior

The search window should:

- appear centered on the current monitor
- be visually compact
- stay above normal windows while open
- receive keyboard focus immediately
- not appear as a normal taskbar application if this can reasonably be avoided
- support repeated open/close cycles

The application must not create a new window instance every time the hotkey is pressed.

Prefer creating one persistent launcher window and showing/hiding it.

## Basic UI

Create:

- search box
- results container
- empty state

At this phase the UI can contain placeholder results.

Example:

    Search anything...

    No results

Styling direction:

- minimal
- modern
- clean
- large search field
- rounded corners
- subtle shadow
- no unnecessary borders
- compact dimensions
- dark/light theme awareness where practical

Do not copy macOS assets.

Do not use Apple logos or copyrighted Apple UI assets.

## Keyboard behavior

Implement:

- text input
- Up
- Down
- Enter
- Escape

For now, Enter can execute a placeholder action.

At the end of the phase:

Test:

1. Start application.
2. Press Alt + Space.
3. Confirm window appears.
4. Confirm text box is focused.
5. Press Escape.
6. Confirm window hides.
7. Repeat at least 10 times.
8. Confirm no duplicate windows appear.

STOP after completing this phase.

---

# PHASE 2 — APPLICATION SEARCH

Goal:

Make the launcher useful by searching installed/available applications.

The application search provider should discover applications from appropriate Windows locations, such as Start Menu shortcuts and other reliable application registration sources.

Do NOT recursively scan the entire C: drive.

Do NOT search Program Files on every keystroke.

Create a dedicated provider:

    IApplicationSearchProvider

Example conceptual model:

    SearchResult
        Id
        Title
        Subtitle
        Category
        Icon
        Path
        SearchScore
        ResultType
        Action

The exact model design is your responsibility, but keep it simple.

## Index strategy

Application discovery should happen:

- on startup
- or lazily on first application search
- and then remain cached

Do not rebuild the application index for every query.

Support:

- application name matching
- abbreviation-like matching
- prefix matching
- basic fuzzy matching

Examples:

    chrome

→ Google Chrome

    vscode

→ Visual Studio Code

    code

→ Visual Studio Code

    termina

→ Windows Terminal

The matching algorithm should be deterministic.

Do not introduce an AI model.

## Result ranking

Start with a simple score model.

Suggested priority:

1. exact match
2. prefix match
3. token match
4. fuzzy match

Do not overcomplicate ranking yet.

## Launching applications

When the user presses Enter on an application:

- launch it
- hide the launcher

Handle launch failures gracefully.

## Icons

Display the application's icon where practical.

If icon extraction fails:

- use a generic application icon

Do not allow missing icons to crash the UI.

At the end of the phase:

Test at least:

- Chrome
- Visual Studio Code
- Windows Terminal
- an application with multiple words
- an application whose name is typed approximately

Test:

- Up
- Down
- Enter
- Escape

STOP after completing this phase.

---

# PHASE 3 — FILE AND FOLDER SEARCH

Goal:

Add file and folder search.

IMPORTANT:

Do NOT implement your own full filesystem indexing engine in this phase.

The preferred strategy is to use the Windows Search Index.

Use Windows Search capabilities and appropriate Windows APIs/query mechanisms.

Programmatic queries should prefer canonical Windows Search syntax where relevant rather than relying on localized UI keywords.

Do not block the UI thread while querying.

## Provider architecture

Create a dedicated:

    IFileSearchProvider

and, if useful:

    IFolderSearchProvider

The provider should return the same general SearchResult abstraction used by application search.

## Search behavior

Examples:

    invoice

    ISO 27001

    Terra

    project

Results can include:

- files
- folders

Display:

- file/folder name
- path or parent folder
- result type
- icon where practical

Example:

    📄 Invoice Client A.xlsx
       C:\Users\Ammar\Documents\Client A

    📁 Terra
       D:\Projects\Terra

## Performance

The application must NOT:

    Directory.GetFiles("C:\\", SearchOption.AllDirectories)

for every query.

No full drive scan per keystroke.

Search requests should be asynchronous.

Implement cancellation for stale queries.

If the user types:

    inv

then quickly changes to:

    invoice

the result of the old query should not overwrite the latest query.

## Query debounce

Introduce a small debounce delay.

Approximately:

    100–200 ms

Use a sensible implementation rather than a blocking sleep.

## Result limiting

Initially return a limited number of results, for example:

    top 8–10

Do not load thousands of results into the UI.

## File actions

For a selected file:

Enter:

- open the file using the associated Windows application

Provide an alternate action for:

- open containing folder / reveal in Explorer

Do not build a context menu yet unless needed.

## Missing/unindexed content

Gracefully handle cases where a requested location is not indexed.

Do not pretend all files are searchable if Windows Search does not index them.

Document the limitation.

At the end of the phase:

Test:

- `.txt`
- `.pdf`
- `.docx`
- `.xlsx`
- folders
- files in Documents
- files in Desktop
- files in another indexed location

Test rapid typing.

Test query cancellation.

STOP after completing this phase.

---

# PHASE 4 — SEARCH ORCHESTRATION + RANKING

Goal:

Combine the different providers into one unified search experience.

At this point we should have:

- Application search
- File search
- Folder search

Create a search orchestration layer.

Conceptually:

    SearchOrchestrator
        ├── ApplicationProvider
        ├── FileProvider
        └── FolderProvider

The UI should not know how any provider performs its search.

## Unified results

The launcher should display mixed results.

Example:

    chrome

    ▣ Google Chrome
       Application

    📄 Chrome Settings Guide.pdf
       File

    📁 Chrome
       Folder

## Ranking

Implement a deterministic ranking system.

Suggested conceptual score:

    finalScore =
        textRelevance
        + resultTypeBoost
        + exactMatchBoost
        + prefixMatchBoost
        + usageBoost
        + recencyBoost

Do not use arbitrary numbers without documenting their purpose.

Create constants or configuration for ranking weights.

## Result categories

Results should have a clear type:

- Application
- File
- Folder

Potential future types should be possible, but do not implement them yet.

## Search cancellation

A newer query must cancel or invalidate older searches.

Ensure asynchronous results cannot reorder themselves incorrectly.

Example:

User types:

    v

then:

    vs

then:

    vsc

Only `vsc` should determine the final displayed result set.

## Empty state

When no result exists:

    No results for "something"

Do not simply show a blank screen.

## Loading state

For a search that takes noticeable time:

    Searching...

Do not show a loading animation for extremely fast queries if it causes visual flicker.

At the end of the phase:

Test mixed application/file queries.

Test rapid typing.

Test empty queries.

Test no-result queries.

Test result ordering.

STOP after completing this phase.

---

# PHASE 5 — CALCULATOR + QUICK ACTIONS

Goal:

Add utility capabilities that make the launcher behave more like a productivity launcher.

## Calculator

Support simple mathematical expressions.

Examples:

    25 * 35

    100 / 4

    15% * 2500000

    (50 + 25) * 2

Display:

    25 × 35 = 875

The calculator must NOT execute arbitrary code.

Do not use:

    eval()

Do not dynamically compile user input.

Use a safe expression parser or implement a restricted arithmetic parser.

Support only clearly defined operations.

Start with:

- addition
- subtraction
- multiplication
- division
- percentages
- parentheses
- decimals

## Calculator ranking

If a query clearly looks like a mathematical expression:

- calculator should rank highly.

Example:

    2500000 * 15%

should prioritize calculator.

## Copy result

Provide an action to copy the calculated result to the clipboard.

## Quick system actions

Add a small set of useful Windows actions, such as:

- Open Settings
- Open Task Manager
- Open File Explorer
- Open Windows Terminal

Do not add dozens of commands.

Create a clean mechanism so additional commands can be added later.

At the end of the phase:

Test mathematical expressions thoroughly.

Especially test malformed input.

The application must never crash because of invalid calculator syntax.

STOP after completing this phase.

---

# PHASE 6 — USAGE HISTORY + SQLITE

Goal:

Make ranking personalized.

Use a lightweight local SQLite database.

Store minimal data.

Example:

    UsageRecord
        ItemId
        ItemType
        LaunchCount
        LastUsedAt

Do NOT store full search history by default.

The goal is usage ranking, not surveillance.

## Track

Track successful execution of:

- applications
- files
- folders
- quick actions

For example:

    Visual Studio Code
        LaunchCount: 143
        LastUsedAt: ...

## Ranking

Use:

- text relevance
- exact/prefix match
- usage count
- recent usage

An item frequently used should receive a moderate ranking advantage.

Do not allow usage history to completely override relevance.

Example:

A frequently used Chrome result should not appear when the user searches for "invoice" unless it is actually relevant.

## Database behavior

The application must:

- initialize DB automatically
- create schema when first launched
- handle DB corruption gracefully
- keep DB local

Do not require an external database server.

## Privacy

All usage data must remain local.

No cloud analytics.

No remote telemetry.

At the end of the phase:

Demonstrate that:

1. launching an item records usage
2. reopening the same query improves ranking appropriately
3. irrelevant items are not promoted excessively

STOP after completing this phase.

---

# PHASE 7 — WINDOWS INTEGRATION + POLISH

Goal:

Turn the project into a proper background Windows utility.

Implement:

## System tray

When running:

- application should have a system tray icon
- launcher window should not dominate the taskbar

Tray menu:

    Open Spotlight
    Settings
    Exit

Do not create a complex settings window yet.

## Start with Windows

Provide a sensible way to start the application automatically with Windows.

Prefer a user-level startup mechanism that does not require administrator privileges.

Make startup behavior optional/configurable.

## Single instance

Only one instance of the application should run.

If another instance starts:

- it should communicate with the existing instance if practical
- or exit cleanly

Do not allow multiple global hotkey registrations.

## Window positioning

Handle:

- multiple monitors
- different DPI/scaling configurations
- monitor where the cursor currently is
- monitor where the active window resides

Choose a deterministic strategy.

The launcher should not randomly appear on the wrong monitor.

## Focus handling

When opened:

- focus search box

When closed:

- return focus to the previous application where practical

Avoid focus-stealing bugs.

## Escape behavior

Escape should:

- dismiss launcher
- clear temporary state
- preserve application state safely

## Theme

Support:

- Light
- Dark
- System

Use WPF resources/styles.

Do not hardcode colors throughout individual controls.

## Visual polish

Improve:

- spacing
- typography
- result selection
- icon alignment
- corner radius
- shadow
- animations

Animations must be subtle and fast.

Never sacrifice search responsiveness for visual effects.

At the end:

Test repeated open/close cycles.

Test:

- multiple monitors
- different DPI scaling
- startup
- tray
- single instance
- application launch
- file launch

STOP after completing this phase.

---

# PHASE 8 — WEB SEARCH FALLBACK

Goal:

Provide web search when no strong local result exists.

Behavior:

User types:

    what is iso 27001

If there are no meaningful local results, show:

    🌐 Search "what is iso 27001"
       Web

Press Enter:

- open the default browser
- search the query using the configured search engine

Do not embed a browser.

Do not create a web crawler.

Do not call remote APIs for every keystroke.

Web search should be a fallback action, not the primary search engine.

Support a configurable search URL template.

Example conceptual configuration:

    https://www.google.com/search?q={query}

Do not hardcode provider-specific assumptions throughout the code.

At the end of the phase:

Test:

- common search queries
- empty query
- special characters
- Indonesian text
- URLs

STOP after completing this phase.

---

# PHASE 9 — SETTINGS

Goal:

Create a minimal settings experience.

Settings should include only useful configuration.

Initial settings:

## General

- Start with Windows
- Launch shortcut
- Number of visible results

## Appearance

- System
- Light
- Dark

## Search

Enable/disable providers:

- Applications
- Files
- Folders
- Calculator
- Web

## Behavior

- Close after launching item
- Show tray icon

Store settings locally.

Do not require administrator rights.

Settings should be versionable so future configuration changes can migrate safely.

STOP after completing this phase.

---

# PHASE 10 — PERFORMANCE + RELEASE HARDENING

Goal:

Make the utility practical for daily use.

Measure:

- startup time
- idle memory
- idle CPU
- search latency
- UI responsiveness

Test with:

- hundreds of applications/shortcuts
- thousands of indexed files
- rapid typing
- repeated searches
- long-running sessions

Look for:

- memory leaks
- event handler leaks
- dangling timers
- unnecessary background tasks
- excessive allocations
- UI thread blocking

Important:

Do not optimize blindly.

Measure first.

## Logging

Ensure logs remain useful but lightweight.

Do not log:

- every keystroke
- every search result
- entire file indexes

## Crash resilience

A single provider failure must not crash the launcher.

## Packaging

Prepare a release build.

Provide:

- self-contained or appropriately portable deployment strategy
- x64 build
- application icon
- executable naming
- version information

Do not create an installer until the application itself is stable.

STOP after completing this phase.

---

# FUTURE ROADMAP — DO NOT IMPLEMENT YET

These are ideas for future versions only.

Possible V2/V3 features:

- custom commands
- user-defined shortcuts
- plugin architecture
- clipboard history
- recent files
- recent applications
- bookmarks
- Windows Settings deep links
- GitHub search
- Spotify control
- Docker commands
- terminal commands
- local semantic search
- document content indexing
- OCR
- AI-powered natural language commands
- Ollama integration
- optional extensions

Do not implement any of these unless explicitly requested.

---

# EXPECTED ARCHITECTURE

The end state should approximately resemble:

    UI
     │
     ▼
    SearchOrchestrator
     │
     ├── ApplicationSearchProvider
     ├── FileSearchProvider
     ├── FolderSearchProvider
     ├── CalculatorSearchProvider
     └── WebSearchProvider
             │
             ▼
          Ranking
             │
             ▼
         SearchResult
             │
             ▼
        Result Action
             │
             ├── Launch Application
             ├── Open File
             ├── Open Folder
             ├── Copy Result
             └── Open Browser

Supporting services:

    WindowsHotkeyService
    WindowManager
    UsageTrackingService
    SettingsService
    LoggingService

Keep these components independently testable.

---

# QUALITY STANDARD

Before saying a phase is complete, verify:

[ ] Solution builds successfully
[ ] No obvious compile warnings introduced
[ ] Relevant automated tests pass
[ ] Application starts
[ ] Application closes cleanly
[ ] No unhandled exceptions in normal operation
[ ] UI remains responsive
[ ] Current-phase requirements are implemented
[ ] Future-phase functionality has NOT been prematurely implemented
[ ] Architecture remains understandable
[ ] No unnecessary dependencies were added

At the end of every phase, report:

## Implementation Summary

## Files Created

## Files Modified

## Dependencies

## Architecture Decisions

## Tests Executed

## Build Result

## Known Limitations

## How to Run

Then STOP.

Do not continue automatically to the next phase.