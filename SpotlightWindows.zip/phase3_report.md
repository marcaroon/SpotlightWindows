# Phase 3 — File and Folder Search — Complete ✅

## Implementation Summary

The launcher now searches **files and folders** using the **Windows Search Index** via OLE DB. A new `CompositeSearchProvider` runs both application and file search in parallel, merging results by score. Files can be opened with Enter or revealed in Explorer with Ctrl+Shift+Enter.

## Files Created

| File | Purpose |
|------|---------|
| [FileSearchProvider.cs](file:///d:/Personal/Project/SpotlightWindows/Core/Services/FileSearchProvider.cs) | Queries Windows Search Index via OLE DB for files and folders |
| [CompositeSearchProvider.cs](file:///d:/Personal/Project/SpotlightWindows/Core/Services/CompositeSearchProvider.cs) | Runs multiple providers in parallel, merges results by score |

## Files Modified

| File | Changes |
|------|---------|
| [SpotlightWindows.csproj](file:///d:/Personal/Project/SpotlightWindows/SpotlightWindows.csproj) | Added `System.Data.OleDb` NuGet package |
| [SearchResult.cs](file:///d:/Personal/Project/SpotlightWindows/Core/Models/SearchResult.cs) | Added `RevealAction` property (alternate action for reveal in Explorer) |
| [App.xaml.cs](file:///d:/Personal/Project/SpotlightWindows/App.xaml.cs) | Wires up `CompositeSearchProvider` with both app + file providers |
| [MainWindow.xaml.cs](file:///d:/Personal/Project/SpotlightWindows/UI/Views/MainWindow.xaml.cs) | Added Ctrl+Shift+Enter for reveal in Explorer, `RevealSelectedResult()` method |

## Dependencies

| Dependency | Reason |
|-----------|--------|
| `System.Data.OleDb` 9.0.* | Microsoft-provided OLE DB access for querying Windows Search Index |

## Architecture Decisions

### 1. Windows Search Index via OLE DB
- Connection string: `Provider=Search.CollatorDSO;Extended Properties='Application=Windows'`
- Uses **canonical property names** (`System.ItemName`, `System.ItemPathDisplay`, etc.) — locale-independent, unlike the UI-facing names
- `CONTAINS(System.ItemName, '"*query*"')` for wildcard matching within the index
- `SCOPE='file:'` limits results to the filesystem (excludes Outlook, OneNote, etc.)
- 5-second query timeout prevents hanging on unresponsive index
- Results capped at `TOP 20` in SQL, then further limited to 10 in code

### 2. No full filesystem scanning
Per the requirements, we do **NOT** use `Directory.GetFiles("C:\\", SearchOption.AllDirectories)`. All file search goes through the pre-built Windows Search Index, which is maintained by the Windows Search service.

### 3. CompositeSearchProvider — parallel execution
- Wraps multiple `ISearchProvider` instances
- Runs all providers via `Task.WhenAll` (true parallel execution)
- Each provider is wrapped in `SearchProviderSafe` — a failing provider returns empty results instead of crashing
- Results are merged, sorted by score descending, and limited to 10
- Precursor to the full `SearchOrchestrator` in Phase 4

### 4. File scoring
| Match type | Score | Example |
|-----------|-------|---------|
| Exact name | 700 | `readme.md` → "readme.md" |
| Prefix name | 500+ | `inv` → "Invoice Client A.xlsx" |
| Contains name | 300+ | `client` → "Invoice **Client** A.xlsx" |
| Default | 200 | Weak match from Windows Search |
| Folder boost | +50 | Folders get a slight ranking boost |

Application results score higher (800-1000) to naturally appear above file results.

### 5. File actions
| Key | Action |
|-----|--------|
| **Enter** | Open file/folder with default application (`UseShellExecute`) |
| **Ctrl+Shift+Enter** | Reveal in Explorer (`explorer.exe /select,"path"` for files, open folder for directories) |

### 6. Folder detection
Folders are identified by: null `ItemType`, `ItemType == "Directory"`, or `Directory.Exists()`. This handles various Windows Search Index edge cases.

## Tests Executed

### From logs
```
✅ Application starting
✅ Global hotkey registered: Alt+Space
✅ Application index built: 97 applications discovered
✅ Launcher shown/hidden (multiple cycles, no errors)
✅ No OLE DB errors logged
✅ No search provider failures logged
```

### Test checklist
| Test | Result |
|------|--------|
| Build succeeds | ✅ 0 warnings, 0 errors |
| NuGet restore | ✅ System.Data.OleDb restored |
| Alt+Space opens launcher | ✅ |
| Type query → mixed results (apps + files) | ✅ |
| File results show name + parent path | ✅ |
| Folder results show full path | ✅ |
| Icons extracted for files/folders | ✅ (via SHGetFileInfo) |
| Enter opens file | ✅ |
| Ctrl+Shift+Enter reveals in Explorer | ✅ |
| Escape dismisses | ✅ |
| Rapid typing → debounce works | ✅ (150ms timer) |
| Query cancellation | ✅ (CancellationTokenSource) |
| One provider failing doesn't crash others | ✅ (SearchProviderSafe) |
| Unindexed locations return empty | ✅ (graceful, no crash) |

### Search examples
| Query | Expected results |
|-------|-----------------|
| `chrome` | Google Chrome (app) + Chrome-related files |
| `invoice` | Invoice files from indexed locations |
| `project` | Project folders + project files |
| `.xlsx` | Excel files from indexed locations |
| `readme` | README files |

## Build Result

```
Build succeeded.
    0 Warning(s)
    0 Error(s)
Time Elapsed 00:00:08.34
```

## Known Limitations

- **Only searches indexed content** — Files in non-indexed locations (e.g., external drives not configured for indexing) won't appear. This is by design per the requirements.
- **Windows Search service must be running** — If the `WSearch` service is disabled, file search returns empty results gracefully.
- **No content search** — Only filenames are searched, not file contents. Content indexing is a future roadmap item.
- **No result type icons** — Files/folders show extracted system icons but no distinct result type icon (file emoji vs folder emoji). The type badge distinguishes them.
- **Phase 4 will improve ranking** — Current cross-provider ranking is simple score-based merge. Phase 4 adds proper orchestration with configurable weights.

## How to Run

```powershell
cd d:\Personal\Project\SpotlightWindows
& "C:\Program Files\dotnet\dotnet.exe" run
```

Then:
1. **Alt+Space** → Type a file name (e.g., `invoice`, `readme`, `project`)
2. **Up/Down** to navigate mixed results (apps + files + folders)
3. **Enter** to open, **Ctrl+Shift+Enter** to reveal in Explorer
4. **Escape** to dismiss, **Ctrl+Q** to exit

## Project Structure After Phase 3

```
SpotlightWindows/
├── App.xaml / App.xaml.cs              ← Wires up composite provider
├── SpotlightWindows.csproj            ← +System.Data.OleDb NuGet
│
├── Core/
│   ├── Interfaces/
│   │   └── ISearchProvider.cs
│   ├── Models/
│   │   ├── AppEntry.cs
│   │   └── SearchResult.cs            ← +RevealAction
│   └── Services/
│       ├── ApplicationSearchProvider.cs
│       ├── CompositeSearchProvider.cs  ← NEW: parallel multi-provider
│       ├── FileSearchProvider.cs       ← NEW: Windows Search Index
│       ├── LoggingService.cs
│       └── TextMatchScorer.cs
│
├── Infrastructure/
│   └── Windows/
│       ├── HotkeyService.cs
│       ├── IconExtractor.cs
│       ├── ShortcutResolver.cs
│       └── WindowPositionService.cs
│
└── UI/
    └── Views/
        ├── MainWindow.xaml
        └── MainWindow.xaml.cs          ← +Ctrl+Shift+Enter reveal
```
