# Phase 4 — Search Orchestration & Ranking — Complete (build on Windows still required) ⚠️

> [!IMPORTANT]
> **This phase was developed in a Linux sandbox without WPF.** The pure logic (scoring, orchestration) was
> compiled and tested for real (44 automated tests). The WPF/Win32/OLE DB parts were only
> compile-checked against stubs and reviewed by reading. **Please run `dotnet build` and the manual checklist below on
> your machine before treating Phase 4 as done.** Earlier phase reports claimed "0 warnings, 0 errors"
> from a real build; this one cannot.

> [!NOTE]
> **Scope was inferred.** The zip contains no Phase 4 spec. Scope comes from the Phase 3 report
> ("full SearchOrchestrator… proper orchestration with configurable weights… improve ranking") and from a
> half-written `SearchOrchestrator.cs` that was in the zip but never wired in. If your Phase 4 spec had other items
> (e.g. calculator, web search, system actions), they are **not** done.

## Implementation Summary

`SearchOrchestrator` is now the single entry point for search. It runs all providers in parallel off the UI thread,
enforces hard per-provider timeouts, applies per-provider weights, deduplicates, and — the main user-visible change —
**publishes results progressively**: applications appear as soon as they are ready, file results are merged in when the
Windows Search Index answers, instead of the UI waiting for the slowest provider.

## Problems found in the existing code (and fixed)

| # | Problem | Evidence | Fix |
|---|---------|----------|-----|
| 1 | Orchestrator header promised "progressive result merging" but used `Task.WhenAll` (waits for the slowest provider) | `SearchOrchestrator.cs` as delivered | Real progressive merging via `Task.WhenAny` + `SearchSnapshot` |
| 2 | First search froze the UI ~2 s: `ApplicationSearchProvider` builds its index **synchronously on the calling thread**, and timeouts can't interrupt synchronous code | Mutation test: with providers called directly, the call blocks 500 ms and the hung-provider test takes 1500 ms | Each provider runs via `Task.Run`; timeout *abandons* the provider (`WaitAsync`); index pre-warmed in background at startup |
| 3 | `MainWindow` read `cts.Token` after `CancelPendingSearch()` had disposed the CTS → `ObjectDisposedException` → generic `catch` **cleared the newer search's results** | Code reading (`cts.Token` throws after `Dispose`) | Token captured up front; stale searches can no longer touch the UI |
| 4 | App results ranked **below** files for ordinary queries: `chrome` → `Chrome Downloads` and `chrome.exe` above the Google Chrome app | Ranking table below, produced with the real scorers | New word-start tier in `TextMatchScorer` + file weight 0.5 |
| 5 | File search took `TOP 20 … ORDER BY ItemName` and *then* scored, so the best match could be cut off before ranking | Code reading | Pool of 100 candidates, score all, keep top 10 |
| 6 | Icons were extracted for every candidate before the top-N cut (apps) / for every row read (files) | Code reading | Rank first, extract icons only for the winners; icon cache for apps |
| 7 | Folders never got an icon: `IconExtractor` required `File.Exists`, false for directories (Phase 3 report claimed folder icons ✅) | Code reading | Also accept `Directory.Exists` |
| 8 | Extension-less files (`LICENSE`, `Makefile`) were classified as folders (empty `ItemType` ⇒ folder) | Code reading | Empty `ItemType` now verified with `Directory.Exists` |
| 9 | Orchestrator multiplied `Score` in place and deduplicated "first seen wins" — with progressive delivery that would depend on arrival order and could double-apply weights | Mutation tests 2 & 3 | Weight applied exactly once at ingestion; dedupe = higher score, ties → registration order |
| 10 | Dedupe by target `.exe` would have merged distinct Start Menu entries sharing one target (e.g. `mmc.exe`) | Reasoning | App `Id` is now the shortcut path (unique); side effect: the indexed `<App>.lnk` file result collapses into the app result |

## Files

**New:** `Core/Interfaces/IProgressiveSearchProvider.cs`, `Core/Models/SearchSnapshot.cs`, `Core/Services/FileMatchScorer.cs`,
`Tests/SpotlightWindows.CoreTests/*` (8 files)

**Changed:** `SearchOrchestrator.cs` (rewritten), `ApplicationSearchProvider.cs`, `FileSearchProvider.cs`,
`TextMatchScorer.cs`, `IconExtractor.cs`, `App.xaml.cs`, `MainWindow.xaml.cs`, `SpotlightWindows.csproj`
(excludes `Tests\**` from the app build)

**Deleted:** `CompositeSearchProvider.cs` (superseded, as planned in Phase 3)

**Dependencies:** none added.

## Ranking

Production weights (`App.xaml.cs`): **applications 1.0, files 0.5**. Hand-tuned; see limitations.

New scorer tier: *word-start* (query is the beginning of a word in the name, e.g. `chrome` → "Google **Chrome**"), 400–499,
between abbreviation (500+) and contains (300+).

Ranking on a synthetic catalogue (14 apps, 14 files), real scorers + production weights (`dotnet run -- --table`):

| Query | Result order (score) |
|-------|----------------------|
| `chrome` | Google Chrome app (446) › Chrome Downloads folder (294) › chrome.exe (280) |
| `code` | Visual Studio Code app (422) › `code` folder (375) › code.txt (275) |
| `term` | Windows Terminal app (425) › terminal-notes.txt (261) |
| `note` | Notepad app (857) › notepad.exe (268) |
| `report` (no app) | `report` folder (375) › report.docx (277) › Annual Report 2025.pdf (157) |

Before (old scorer, weight 0.75), `chrome` gave: Chrome Downloads (441) › chrome.exe (420) › Google Chrome (346).

## Verification

### Automated (run here, Linux, .NET 10.0.112): `dotnet run --project Tests/SpotlightWindows.CoreTests`

```
44 passed, 0 failed
```

Covers: scorer tier ordering; file scoring; app-vs-file ranking intent (8 scenarios); orchestrator progressive delivery,
weight applied once, order-independent dedupe, hard timeout on a provider that blocks synchronously, caller thread
not blocked, failing-provider isolation, cancellation (nothing published afterwards), empty query, `MaxResults`.

The orchestrator tests were **mutation-checked**: reverting to direct provider calls, first-seen dedupe, or double
weighting each makes the relevant tests fail (3, 2 and 4 failures respectively), so they are not vacuous.

### Compile-checked only (not run)
`FileSearchProvider`, `ApplicationSearchProvider` (against stubs of `OleDb*`, `IconExtractor`, `ShortcutResolver`) and
`MainWindow.xaml.cs` (against signature-faithful WPF stubs): 0 errors. `App.xaml.cs` and the XAML were not compiled.

### NOT verified — you must check on Windows
- [ ] `dotnet build` succeeds (whole app)
- [ ] Press Alt+Space right after starting the app, type immediately: no freeze
- [ ] Type fast / change the query mid-search: results never blank out or flicker
- [ ] Type `chrome` (or any installed app that also has files): the app is the top result
- [ ] Press ↓ while file results are still arriving, wait: the highlighted item stays the same item
- [ ] Folder results now show an icon; an extension-less file (e.g. `LICENSE`) is labelled File, not Folder
- [ ] `Logs`: `%LOCALAPPDATA%\SpotlightWindows\spotlight.log` shows `Registered search provider` ×2, `warm-up finished`, and per-provider timings
- [ ] Optional: `dotnet run --project Tests/SpotlightWindows.CoreTests` on Windows too

## Known limitations / open risks

- **Possible Phase 3 issue (unverified):** the file query uses `CONTAINS(System.ItemName, '"*text*"')`. As far as I know, Windows Search full-text
  `CONTAINS` only honours a trailing `*` (word-prefix), not a leading one, so mid-word matches (`port` → `report.docx`) may not be returned.
  I could not test OLE DB here. Quick check: search for a mid-word fragment of a file you know is indexed. If it fails, the fix is
  `System.ItemName LIKE '%text%'` (slower, but correct).
- **Abandoned file queries keep running.** The orchestrator stops waiting at 3 s, but OLE DB `ExecuteReader` isn't cancellable and its
  `CommandTimeout` is 5 s, so a hung index can leave a few background queries running while you keep typing.
- **Weights are hand-tuned** on a synthetic catalogue, not on your real usage. Phase 6 (usage history) should replace them; until then the
  `RankingTests` are the guard against silent regressions.
- **Fuzzy noise:** `code` also returns *Microsoft Edge* via the fuzzy tier (letters c-o-d-e appear in order). Pre-existing Phase 2 behaviour; not changed.
- **Pre-existing:** pressing Enter inside the 150 ms debounce window launches the *previous* query's selection; the app index is never refreshed
  after startup; weights are code constants, not settings.

## How to run

```powershell
cd d:\Personal\Project\SpotlightWindows
& "C:\Program Files\dotnet\dotnet.exe" run
# tests (no Windows needed):
& "C:\Program Files\dotnet\dotnet.exe" run --project Tests\SpotlightWindows.CoreTests
& "C:\Program Files\dotnet\dotnet.exe" run --project Tests\SpotlightWindows.CoreTests -- --table
```
