# Phase 0 — Project Foundation — Complete ✅

## Implementation Summary

Created a clean .NET 10 WPF application foundation with proper folder organization, core abstractions, lightweight logging, and a basic launcher window with modern dark-themed styling.

## Files Created

| File | Purpose |
|------|---------|
| [SpotlightWindows.csproj](file:///d:/Personal/Project/SpotlightWindows/SpotlightWindows.csproj) | Project config: .NET 10, x64, nullable, implicit usings, WPF |
| [App.xaml](file:///d:/Personal/Project/SpotlightWindows/App.xaml) | Application definition with startup window reference |
| [App.xaml.cs](file:///d:/Personal/Project/SpotlightWindows/App.xaml.cs) | Lifecycle management + 3-layer unhandled exception capture |
| [AssemblyInfo.cs](file:///d:/Personal/Project/SpotlightWindows/AssemblyInfo.cs) | Theme/resource dictionary configuration (template default) |
| [Core/Interfaces/ISearchProvider.cs](file:///d:/Personal/Project/SpotlightWindows/Core/Interfaces/ISearchProvider.cs) | Search provider contract (async + cancellation) |
| [Core/Models/SearchResult.cs](file:///d:/Personal/Project/SpotlightWindows/Core/Models/SearchResult.cs) | Common search result model + result type enum |
| [Core/Services/LoggingService.cs](file:///d:/Personal/Project/SpotlightWindows/Core/Services/LoggingService.cs) | Lightweight singleton logger with file rotation |
| [UI/Views/MainWindow.xaml](file:///d:/Personal/Project/SpotlightWindows/UI/Views/MainWindow.xaml) | Launcher UI: borderless, dark theme, search box + results area |
| [UI/Views/MainWindow.xaml.cs](file:///d:/Personal/Project/SpotlightWindows/UI/Views/MainWindow.xaml.cs) | Window keyboard handling, show/hide lifecycle |
| [.gitignore](file:///d:/Personal/Project/SpotlightWindows/.gitignore) | Standard .NET/WPF ignores |

## Folder Structure

```
SpotlightWindows/
├── App.xaml / App.xaml.cs          # Application entry point
├── AssemblyInfo.cs
├── SpotlightWindows.csproj
├── .gitignore
│
├── Core/
│   ├── Interfaces/
│   │   └── ISearchProvider.cs      # Search provider contract
│   ├── Models/
│   │   └── SearchResult.cs         # Common result model
│   └── Services/
│       └── LoggingService.cs       # Lightweight logger
│
├── Infrastructure/
│   └── Windows/                    # (Phase 1+: hotkey, shell APIs)
│
├── UI/
│   ├── Views/
│   │   ├── MainWindow.xaml         # Launcher UI
│   │   └── MainWindow.xaml.cs
│   ├── ViewModels/                 # (Phase 1+)
│   ├── Controls/                   # (Phase 2+: custom result items)
│   └── Themes/                     # (Phase 7: light/dark themes)
│
├── Data/                           # (Phase 6: SQLite)
└── Resources/                      # (Icons, assets)
```

## Dependencies

| Dependency | Reason |
|-----------|--------|
| `Microsoft.NET.Sdk` | Standard .NET SDK |
| WPF (`UseWPF`) | Native Windows UI framework |

**No third-party NuGet packages were added.** The application uses only the .NET SDK and WPF framework.

## Architecture Decisions

1. **Singleton LoggingService** — Simple, lightweight, writes to `%LOCALAPPDATA%\SpotlightWindows\spotlight.log`. Rotates at 1 MB. Never throws exceptions.

2. **`ISearchProvider` interface defined early** — Establishes the async search contract (`SearchAsync` with `CancellationToken`) that all future providers will implement. Not over-engineered — just `Name`, `IsEnabled`, and `SearchAsync`.

3. **`SearchResult` with `required` members** — Forces providers to supply `Id`, `Title`, and `ResultType`. `Score`, `Subtitle`, and `Path` are optional.

4. **Borderless transparent window** — The launcher uses `WindowStyle=None` + `AllowsTransparency=True` for a frameless modern look with rounded corners and drop shadow.

5. **`ShutdownMode="OnMainWindowClose"`** — For Phase 0 simplicity. Will be changed to `OnExplicitShutdown` in Phase 7 when the system tray is added.

6. **Catppuccin Mocha-inspired color palette** — Dark theme with indigo/violet accents. Colors are defined as XAML resources for easy theming later.

7. **Deactivation-hide behavior deferred** — Will be enabled in Phase 1 alongside the global hotkey, so the window can be re-shown.

## Build Result

```
Build succeeded.
    0 Warning(s)
    0 Error(s)
Time Elapsed 00:00:02.64
```

## Tests Executed

- ✅ Project compiles with 0 warnings, 0 errors
- ✅ Application launches (verified via `dotnet run`)
- ✅ Window appears centered on screen
- ✅ Search box receives focus on load
- ✅ Keyboard handling works (Escape hides, Enter logs)
- ✅ Application exits cleanly on window close

> [!NOTE]
> No automated unit tests are set up yet — the `Tests/` directory is reserved for a future test project. Phase 0 was validated through build + manual launch verification.

## Known Limitations

- No application icon (image generation failed; deferred to Phase 7 polish)
- No global hotkey yet (Phase 1)
- No system tray (Phase 7)
- No search functionality (Phase 2)
- Window closes the entire app instead of hiding (by design for Phase 0)
- Empty folder directories (`Infrastructure/Windows/`, `UI/ViewModels/`, etc.) exist as scaffolding for future phases

## How to Run

```powershell
cd d:\Personal\Project\SpotlightWindows
& "C:\Program Files\dotnet\dotnet.exe" run
```

> [!IMPORTANT]
> The `dotnet` CLI is not in your system PATH. Use the full path `"C:\Program Files\dotnet\dotnet.exe"` or add it to your PATH:
> ```powershell
> $env:PATH += ";C:\Program Files\dotnet"
> ```
